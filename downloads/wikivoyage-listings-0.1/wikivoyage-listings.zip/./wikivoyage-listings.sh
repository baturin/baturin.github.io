#!/bin/sh

java -cp "wikivoyage-listings.jar:lib/*:config/" org.wikivoyage.ru.listings.Main "$@"