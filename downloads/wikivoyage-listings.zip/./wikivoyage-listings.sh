#!/bin/sh

java -cp "wikivoyage-listings.jar:lib/*:lib-gl/*" org.wikivoyage.ru.listings.Main "$@"
